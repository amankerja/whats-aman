@echo off
title Update Screenshot Marketing WhatsAman
color 0A
echo ============================================================
echo   MENGAMBIL ULANG SELURUH SCREENSHOT MARKETING WHATSAMAN
echo ============================================================
echo.
cd /d "%~dp0\.."
echo Memastikan dev server atau aplikasi aktif...
node scripts/capture_marketing_screenshots.js
echo.
echo ============================================================
echo   SELESAI! Seluruh screenshot telah diperbarui di folder:
echo   MARKETING_KIT\screenshots\
echo ============================================================
pause
